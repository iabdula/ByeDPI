package io.github.dovecoteescapee.byedpi.data

const val START_ACTION = "start"
const val STOP_ACTION = "stop"
