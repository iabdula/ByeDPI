package io.github.dovecoteescapee.byedpi.data

enum class ServiceStatus {
    Disconnected,
    Connected,
    Failed,
}
