extern struct params default_params;

void reset_params(void);
int parse_args(int argc, char **argv);
